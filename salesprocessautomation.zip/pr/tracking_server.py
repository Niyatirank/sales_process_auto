from flask import Flask, request, send_file
from datetime import datetime
import csv
import os

app = Flask(__name__)

@app.route('/track_open/<email>')
def track_open(email):
    timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    
    # Save to CSV or database
    with open('email_analytics.csv', 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([email, 'opened', timestamp])

    # Return a 1x1 transparent pixel
    return send_file('pixel.png', mimetype='image/png')

if __name__ == '__main__':
    if not os.path.exists('pixel.png'):
        from PIL import Image
        img = Image.new('RGBA', (1, 1), (0, 0, 0, 0))
        img.save('pixel.png')

    app.run(host='0.0.0.0', port=5000)
