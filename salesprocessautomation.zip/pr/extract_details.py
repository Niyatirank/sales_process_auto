import requests
import random
import time
import re
import pandas as pd
import json
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from google_scraper import scrape_google_results

company_data = []

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
}

def extract_emails_from_website(url):
    try:
        response = requests.get(url, timeout=5, headers=HEADERS)
        emails = re.findall(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", response.text)
        return list(set(emails))
    except:
        return []

def extract_company_data(url):
    try:
        response = requests.get(url, timeout=5, headers=HEADERS)
        soup = BeautifulSoup(response.text, 'html.parser')

        title = soup.title.string if soup.title else 'N/A'
        parsed_url = urlparse(url)
        domain = parsed_url.netloc

        company_name = title.split("-")[0].strip() if "-" in title else title

        emails = extract_emails_from_website(url)
        email = emails[0] if emails else None


        time.sleep(random.uniform(2, 4))

        return {
            "Company Name": company_name,
            "Website": domain,
            "URL": url,
            "Industry": "SaaS",
            "Location": "United States",
            "Email": email,
        }

    except Exception as e:
        print(f"Error processing {url}: {e}")
        return None

# Scrape and collect
urls = scrape_google_results()
for url in urls:
    data = extract_company_data(url)
    if data:
        company_data.append(data)

# Optional: print
for company in company_data:
    print(company)

# Save to Excel
df = pd.DataFrame(company_data)
df.to_excel("saas_companies_us.xlsx", index=False)

# Save to JSON
with open("saas_companies_us.json", "w") as f:
    json.dump(company_data, f, indent=4)

print("Saved data to Excel and JSON.")