import smtplib
import pandas as pd
import time
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# List of sender accounts
EMAIL_ACCOUNTS = [
    {"email": "niyatirank28@gmail.com", "password": "tqeilzwltjcdxtlg"},
    # Add more accounts as needed
]

BATCH_SIZE = 2
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

def send_email(sender, recipient_email, subject, html_content):
    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = sender["email"]
        msg["To"] = recipient_email
        msg["Subject"] = subject

        msg.attach(MIMEText(html_content, "html"))

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(sender["email"], sender["password"])
        server.sendmail(sender["email"], recipient_email, msg.as_string())
        server.quit()

        print(f"Sent to {recipient_email} from {sender['email']}")
        return True
    except Exception as e:
        print(f"Failed to send to {recipient_email} from {sender['email']}: {e}")
        return False

def send_batch_emails(df):
    sender_index = 0
    sent_count = 0

    for idx, row in df.iterrows():
        recipient_email = row.get("Email")
        if pd.isna(recipient_email):
            print(f"Skipping row {idx} due to missing email.")
            continue

        company = row.get("Company Name", "your company")
        region = row.get("Location", "your region")
        recipient_name = row.get("Recipient Name", f"Team at {company}")

        tracking_link = f"http://127.0.0.1:5000/click/{recipient_email}?redirect=https://your-target-url.com"

        html_content = f"""
        <html>
            <body>
                <p>Hi {recipient_name},<br><br>
                I recently came across <strong>{company}</strong> while researching innovative SaaS companies in {region}.<br><br>
                We specialize in helping companies like yours streamline their processes using our tools.<br><br>
                Would you be open to a quick call to discuss how we can help {company} achieve even better results?<br><br>
                <a href="http://127.0.0.1:5000/click/{{recipient_email}}?redirect=https://your-target-url.com">Schedule a Call</a><br><br>
                Best regards,<br>
                Niyati Rank<br>
                CodeTech Solution
                </p>
            </body>
        </html>
        """

        sender = EMAIL_ACCOUNTS[sender_index]

        if send_email(sender, recipient_email, f"{company} x CodeTech - Collaboration idea", html_content):
            sent_count += 1
            delay = random.uniform(6, 12)
            print(f" Waiting {delay:.2f} seconds before next email...")
            time.sleep(delay)

        if sent_count >= BATCH_SIZE:
            sender_index = (sender_index + 1) % len(EMAIL_ACCOUNTS)
            sent_count = 0
            print(f"Switching to next sender: {EMAIL_ACCOUNTS[sender_index]['email']}")
            batch_delay = random.uniform(20, 40)
            print(f" Waiting {batch_delay:.2f} seconds before next batch...")
            time.sleep(batch_delay)

# Load data
df = pd.read_excel("company_data.xlsx")
send_batch_emails(df)
