import requests
from config import SERP_API_KEY

def scrape_google_results(query="Top SaaS companies in USA", pages=5):
    base_url = "https://serpapi.com/search"
    results = []

    for page in range(pages):
        print(f"[INFO] Fetching page {page + 1}")
        params = {
            "q": query,
            "engine": "google",
            "start": page * 10,
            "api_key": SERP_API_KEY,
            "num": 10
        }

        response = requests.get(base_url, params=params)

        if response.status_code != 200:
            print(f"[ERROR] Request failed for page {page + 1}: {response.status_code}")
            continue

        try:
            data = response.json()
        except Exception as e:
            print(f"[ERROR] SerpAPI failed on page {page + 1}: {e}")
            print(f"[DEBUG] Raw response page {page + 1}:\n", response.text[:500])
            continue

        organic_results = data.get("organic_results", [])
        urls = [result.get("link") for result in organic_results if result.get("link")]

        results.extend(urls)

    return results
