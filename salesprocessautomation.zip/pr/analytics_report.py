import pandas as pd
import os

EXCEL_FILE = "company_data.xlsx"
CSV_REPORT = "campaign_report.csv"

def generate_report():
    if not os.path.exists(EXCEL_FILE):
        print(f" Excel file '{EXCEL_FILE}' not found.")
        return

    df = pd.read_excel(EXCEL_FILE)
    for col in ["Status", "Opened", "Clicked"]:
        if col not in df.columns:
            df[col] = ""
    total_sent = df[df["Status"] == "Sent"].shape[0]
    total_opened = df[df["Opened"] == "Yes"].shape[0]
    total_clicked = df[df["Clicked"] == "Yes"].shape[0]
    total_leads = df.shape[0]
    cold_leads = df[df["Opened"] != "Yes"].shape[0]

    open_rate = (total_opened / total_sent) * 100 if total_sent > 0 else None
    click_rate = (total_clicked / total_sent) * 100 if total_sent > 0 else None

    print("\nCampaign Report")
    print(f"Emails Sent: {total_sent}")
    print(f"Open Rate: {open_rate:.2f}%" if open_rate is not None else "Open Rate: N/A")
    print(f"Click-through Rate: {click_rate:.2f}%" if click_rate is not None else "Click-through Rate: N/A")
    print(f"Hot Leads (clicked): {total_clicked}")
    print(f"Cold Leads (no open): {cold_leads}")

    # Save CSV report
    report_data = {
        "Emails Sent": [total_sent],
        "Open Rate (%)": [f"{open_rate:.2f}" if open_rate is not None else "N/A"],
        "Click-through Rate (%)": [f"{click_rate:.2f}" if click_rate is not None else "N/A"],
        "Hot Leads (Clicked)": [total_clicked],
        "Cold Leads (No Open)": [cold_leads]
    }

    pd.DataFrame(report_data).to_csv(CSV_REPORT, index=False)
    print(f"\nCSV report saved as: {CSV_REPORT}")

generate_report()
